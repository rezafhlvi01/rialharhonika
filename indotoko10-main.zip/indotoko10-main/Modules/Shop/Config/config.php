<?php

return [
    'name' => 'Shop'
];
